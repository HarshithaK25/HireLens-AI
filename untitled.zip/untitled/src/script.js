
// ==========================================
// TALENTLENS AI - FRONTEND INTELLIGENCE ENGINE
// ==========================================

if (window.pdfjsLib) {
  pdfjsLib.GlobalWorkerOptions.workerSrc =
    "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
}

const $ = id => document.getElementById(id);

let candidates = [
 {
  id:1,name:"Aarav Sharma",experience:2,
  education:"B.Tech Computer Science",
  skills:["Python","SQL","Machine Learning","Pandas","NumPy","Statistics","Data Visualization"],
  projects:["Customer Churn Prediction using ML","Sales Analytics Dashboard"],
  text:"Python SQL machine learning pandas numpy statistics data visualization customer churn prediction sales analytics dashboard",
  source:"Sample Profile"
 },
 {
  id:2,name:"Priya Nair",experience:1,
  education:"B.Tech Data Science",
  skills:["Python","SQL","Power BI","Excel","Statistics","Data Analysis"],
  projects:["Retail Sales Analysis","Business Intelligence Dashboard"],
  text:"Python SQL Power BI Excel statistics data analysis retail sales analysis business intelligence dashboard",
  source:"Sample Profile"
 },
 {
  id:3,name:"Rahul Verma",experience:3,
  education:"B.E. Information Science",
  skills:["Python","Java","SQL","Machine Learning","Deep Learning","TensorFlow","NumPy"],
  projects:["Image Classification","Recommendation System"],
  text:"Python Java SQL machine learning deep learning tensorflow numpy image classification recommendation system",
  source:"Sample Profile"
 },
 {
  id:4,name:"Ananya Rao",experience:0,
  education:"B.Tech Artificial Intelligence",
  skills:["Python","Java","HTML","CSS","JavaScript","SQL","Data Structures"],
  projects:["Student Management System","AI Chatbot"],
  text:"Python Java HTML CSS JavaScript SQL data structures student management system AI chatbot",
  source:"Sample Profile"
 }
];

let selectedFiles = [];
let anonymous = false;
let analyzed = false;

const skillBank = [
 "Python","SQL","Java","C++","JavaScript","HTML","CSS",
 "Machine Learning","Deep Learning","Artificial Intelligence",
 "TensorFlow","PyTorch","Scikit-learn","Pandas","NumPy",
 "Statistics","Power BI","Tableau","Excel","Data Visualization",
 "Data Analysis","NLP","Computer Vision","React","Node.js",
 "Flask","FastAPI","Django","MongoDB","MySQL","PostgreSQL",
 "AWS","Azure","Git","Docker","Data Structures","Problem Solving",
 "Communication","Leadership","Cloud Computing","Big Data"
];

const relatedSkills = {
 "Machine Learning":["Python","Statistics","NumPy","Pandas"],
 "Deep Learning":["Machine Learning","Python","TensorFlow","PyTorch"],
 "Data Science":["Python","Statistics","SQL","Pandas"],
 "Data Analysis":["SQL","Excel","Power BI","Statistics"],
 "Power BI":["Data Analysis","Excel","Data Visualization"],
 "Tableau":["Data Visualization","SQL","Data Analysis"],
 "NLP":["Python","Machine Learning","Deep Learning"],
 "Computer Vision":["Python","Deep Learning","Machine Learning"],
 "FastAPI":["Python","API Development"],
 "Flask":["Python","API Development"],
 "React":["JavaScript","HTML","CSS"],
 "TensorFlow":["Python","Deep Learning","Machine Learning"],
 "Scikit-learn":["Python","Machine Learning","Statistics"]
};

function notify(message) {
 const toast=$("toast");
 toast.textContent=message;
 toast.classList.add("show");
 setTimeout(()=>toast.classList.remove("show"),2500);
}

function go(page) {
 document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
 document.querySelectorAll(".nav").forEach(n=>n.classList.remove("active"));
 $(page).classList.add("active");
 const nav=document.querySelector(`[data-page="${page}"]`);
 if(nav) nav.classList.add("active");
 const title=nav ? nav.textContent.trim() : "Dashboard";
 $("crumb").textContent=title;
 $("pageTitle").textContent=page==="dashboard"?"Recruitment Dashboard":title;
 if(page==="candidates") renderCandidates();
 if(page==="comparison") updateCompare();
 if(page==="improvement") updateImprove();
 if(page==="dashboard") renderDashboard();
 if(page==="reports") updateStats();
}

document.querySelectorAll(".nav").forEach(btn=>{
 btn.addEventListener("click",()=>go(btn.dataset.page));
});

$("anonymousBtn").addEventListener("click",()=>{
 anonymous=!anonymous;
 $("anonymousBtn").textContent="◉ Anonymous: "+(anonymous?"ON":"OFF");
 $("anonymousBtn").style.color=anonymous?"#51d6a0":"#c3c9dc";
 renderCandidates();
 renderDashboard();
 if(analyzed) renderResults();
 notify(anonymous?"Anonymous screening enabled":"Candidate identities visible");
});

// ------------------------------------------
// JOB DESCRIPTION AND SKILL DETECTION
// ------------------------------------------

function normalize(s) {
 return s.toLowerCase().replace(/[^a-z0-9+#.]/g," ");
}

function detectSkills(text) {
 const normalized=normalize(text);
 return skillBank.filter(skill=>{
  const pattern=new RegExp(
   "(^|[^a-z0-9])"+skill.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+"([^a-z0-9]|$)"
  );
  return pattern.test(normalized);
 });
}

function getJD() {
 return $("jd").value;
}

function updateSuggested() {
 const skills=detectSkills(getJD());
 $("suggestedSkills").textContent=skills.length?
 skills.slice(0,12).join(" · "):"No recognized skills detected";
}

$("jd").addEventListener("input",updateSuggested);

// ------------------------------------------
// FILE UPLOAD AND PDF/DOCX EXTRACTION
// ------------------------------------------

$("resumeFiles").addEventListener("change",e=>{
 selectedFiles=[...selectedFiles,...e.target.files];
 renderFileList();
});

function renderFileList() {
 $("fileList").innerHTML=selectedFiles.map((f,i)=>`
 <div class="file-item">
 <span>📄 ${escapeHTML(f.name)}</span>
 <span>${(f.size/1024).toFixed(1)} KB</span>
 </div>`).join("");
}

function escapeHTML(s) {
 return String(s).replace(/[&<>"']/g,c=>({
  "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
 }[c]));
}

async function extractText(file) {
 const ext=file.name.split(".").pop().toLowerCase();

 if(ext==="pdf") {
  if(!window.pdfjsLib) throw Error("PDF reader library unavailable");
  const buffer=await file.arrayBuffer();
  const pdf=await pdfjsLib.getDocument({data:buffer}).promise;
  let text="";
  for(let i=1;i<=pdf.numPages;i++) {
   const page=await pdf.getPage(i);
   const content=await page.getTextContent();
   text+=content.items.map(x=>x.str).join(" ")+" ";
  }
  return text;
 }

 if(ext==="docx") {
  if(!window.mammoth) throw Error("DOCX reader library unavailable");
  const buffer=await file.arrayBuffer();
  const result=await mammoth.extractRawText({arrayBuffer:buffer});
  return result.value;
 }

 throw Error("Only PDF and DOCX are supported");
}

// ------------------------------------------
// RESUME ANALYSIS ENGINE
// ------------------------------------------

function analyzeCandidate(candidate) {
 const jdSkills=detectSkills(getJD());
 const candidateSkills=candidate.skills || detectSkills(candidate.text);
 const text=normalize(candidate.text || "");
 const projects=candidate.projects || [];

 const matched=jdSkills.filter(s=>candidateSkills.includes(s));
 const missing=jdSkills.filter(s=>!candidateSkills.includes(s));

 const skillScore=jdSkills.length?
 Math.round((matched.length/jdSkills.length)*100):0;

 const requiredExperience=Number($("experience").value);
 const experienceScore=requiredExperience===0?
 (candidate.experience>=0?100:0):
 Math.min(100,Math.round(candidate.experience/requiredExperience*100));

 const projectWords=[
  "project","developed","built","implemented","dashboard",
  "prediction","model","application","system","analysis",
  "classification","recommendation","deployment"
 ];

 const projectEvidence=projectWords.filter(w=>text.includes(w)).length;
 const projectScore=Math.min(100,
  projects.length*25+projectEvidence*5);

 const educationScore=/(b\.?tech|b\.?e\.|bachelor|master|degree|computer science|data science|engineering)/.test(text)?90:35;

 const total=Math.round(
  skillScore*.40+
  experienceScore*.20+
  projectScore*.25+
  educationScore*.15
 );

 const hiddenSkills=[];
 candidateSkills.forEach(s=>{
  (relatedSkills[s]||[]).forEach(r=>{
   if(!jdSkills.includes(r)&&!candidateSkills.includes(r)&&!hiddenSkills.includes(r))
    hiddenSkills.push(r);
  });
 });

 const issues=[];
 const dateMatches=text.match(/\b(19|20)\d{2}\b/g)||[];
 if(dateMatches.length>=2) {
  const years=dateMatches.map(Number).sort((a,b)=>a-b);
  if(years[years.length-1]-years[0]>40)
   issues.push("Unusually wide date range detected. Verify timeline.");
 }
 if(candidate.experience===0 && /\b(senior|lead|manager)\b/.test(text))
  issues.push("Seniority wording may need experience verification.");
 if(!candidate.projects?.length && !/project/.test(text))
  issues.push("No clear project evidence found.");
 if(!candidateSkills.length)
  issues.push("No recognized technical skills extracted.");

 const interviewQuestions=[
  `Explain how you would use ${matched[0]||"your main technical skill"} in a real-world project.`,
  `Describe a challenging problem you solved in your projects.`,
  `How would you evaluate the performance of a ${$("jobTitle").value} solution?`,
  `Explain the difference between your strongest technical skill and a related technology.`,
  `What would you improve in your most recent project?`
 ];

 candidate.analysis={
  score:total,skillScore,experienceScore,projectScore,
  educationScore,matched,missing,hiddenSkills,
  issues,interviewQuestions,
  status:total>=75?"Strong Match":total>=50?"Moderate Match":"Low Match"
 };
 return candidate;
}

// ------------------------------------------
// ANALYZE UPLOADED CANDIDATES
// ------------------------------------------

$("analyzeBtn").addEventListener("click",async()=>{
 const btn=$("analyzeBtn");
 btn.disabled=true;
 btn.textContent="Analyzing...";
 $("progress").classList.remove("hidden");

 try {
  const uploaded=[];
  let errors=[];

  for(let i=0;i<selectedFiles.length;i++) {
   const file=selectedFiles[i];
   $("progressBar").style.width=((i+1)/selectedFiles.length*100)+"%";
   $("progressText").textContent="Extracting "+file.name;

   try {
    const text=await extractText(file);
    if(!text.trim()) throw Error("No readable text. It may be a scanned PDF.");
    const skills=detectSkills(text);

    uploaded.push({
     id:Date.now()+i,
     name:file.name.replace(/\.[^.]+$/,""),
     experience:estimateExperience(text),
     education:findEducation(text),
     skills,
     projects:findProjects(text),
     text,
     source:file.name
    });
   } catch(err) {
    errors.push(file.name+": "+err.message);
   }
  }

  if(uploaded.length) {
   candidates=candidates.filter(c=>!uploaded.some(u=>u.name===c.name));
   candidates.push(...uploaded);
  }

  candidates.forEach(analyzeCandidate);
  analyzed=true;
  renderAll();
  renderResults();
  notify(uploaded.length+" resumes processed successfully");
  if(errors.length) alert("Some files could not be processed:\n"+errors.join("\n"));
 } catch(e) {
  notify("Analysis failed: "+e.message);
 } finally {
  btn.disabled=false;
  btn.textContent="✧ Analyze All Candidates";
  $("progress").classList.add("hidden");
 }
});

function estimateExperience(text) {
 const match=text.match(/(\d+)\s*\+?\s*years?\s+(of\s+)?experience/i);
 return match?Number(match[1]):0;
}

function findEducation(text) {
 const match=text.match(/(B\.?Tech|B\.?E\.|BCA|MCA|M\.?Tech|MBA|Bachelor|Master)[^\n,;]{0,60}/i);
 return match?match[0]:"Not specified";
}

function findProjects(text) {
 const lines=text.split(/\n|[.!]/).map(x=>x.trim()).filter(Boolean);
 return lines.filter(x=>/project|developed|built|implemented|created/i.test(x)).slice(0,5);
}

// ------------------------------------------
// RENDERING
// ------------------------------------------

function identity(c) {
 return anonymous?"Candidate #"+c.id:c.name;
}

function renderAll() {
 renderDashboard();
 renderCandidates();
 updateCompare();
 updateImprove();
 updateStats();
}

function renderDashboard() {
 const total=candidates.length;
 const strong=candidates.filter(c=>(c.analysis||analyzeCandidate(c).analysis).score>=75).length;
 const avg=Math.round(candidates.reduce((a,c)=>a+(c.analysis||analyzeCandidate(c).analysis).score,0)/(total||1));
 const unique=new Set(candidates.flatMap(c=>c.skills)).size;

 $("total").textContent=total;
 $("shortlisted").textContent=strong;
 $("average").textContent=avg+"%";
 $("skillsCount").textContent=unique;

 $("chart").innerHTML=candidates.map(c=>{
  const a=c.analysis||analyzeCandidate(c).analysis;
  const color=a.score>=75?"#51d6a0":a.score>=50?"#9874ff":"#ff718b";
  return `<div class="chart-col">
   <b style="font-size:10px">${a.score}%</b>
   <div class="chart-bar" style="height:${a.score}%;background:${color}"></div>
   <small>${escapeHTML(identity(c).split(" ")[0])}</small>
  </div>`;
 }).join("");

 $("insights").innerHTML=`
 <div class="insight"><div class="insight-icon">✧</div><div><b>${strong} strong matches identified</b><small>Based on the current job description</small></div></div>
 <div class="insight"><div class="insight-icon">◈</div><div><b>${unique} unique skills detected</b><small>Technical capabilities across profiles</small></div></div>
 <div class="insight"><div class="insight-icon">◎</div><div><b>Evidence-based evaluation</b><small>Scores are available for human review</small></div></div>`;

 const sorted=[...candidates].sort((a,b)=>b.analysis.score-a.analysis.score);
 $("topCandidates").innerHTML=sorted.slice(0,3).map(candidateRow).join("");
}

function candidateRow(c) {
 const a=c.analysis||analyzeCandidate(c).analysis;
 return `<div class="candidate">
 <div class="candidate-avatar">${escapeHTML(identity(c).slice(0,1).toUpperCase())}</div>
 <div class="candidate-info">
 <b>${escapeHTML(identity(c))}</b>
 <small>${escapeHTML(c.education)} · ${c.experience} years experience</small>
 <div class="badges">${c.skills.slice(0,5).map(s=>`<span class="skill">${escapeHTML(s)}</span>`).join("")}</div>
 </div>
 <div class="score">${a.score}%<small>MATCH</small></div>
 <span class="status ${a.score<50?"low":a.score<75?"mid":""}">${a.status}</span>
 <button class="secondary" onclick="showDetails(${c.id})">Details</button>
 </div>`;
}

function renderCandidates() {
 const search=($("candidateSearch")?.value||"").toLowerCase();
 const sort=$("sortCandidates")?.value||"score";
 let list=[...candidates].filter(c=>
  (c.name+" "+c.skills.join(" ")).toLowerCase().includes(search)
 );
 list.sort((a,b)=>sort==="name"?a.name.localeCompare(b.name):
 sort==="experience"?b.experience-a.experience:
 b.analysis.score-a.analysis.score);

 $("candidateList").innerHTML=list.map(candidateRow).join("")||'<div class="empty">No matching candidates.</div>';
}

function renderResults() {
 $("screenResults").innerHTML=`
 <div class="panel-head"><div><h3>Analysis complete</h3><p>${candidates.length} candidate profiles evaluated</p></div><span class="tag">RANKED RESULTS</span></div>
 ${[...candidates].sort((a,b)=>b.analysis.score-a.analysis.score).map(candidateRow).join("")}`;
}

function updateStats() {
 const total=candidates.length;
 const strong=candidates.filter(c=>c.analysis.score>=75).length;
 const avg=Math.round(candidates.reduce((s,c)=>s+c.analysis.score,0)/(total||1));
 $("reportTotal").textContent=total;
 $("reportShort").textContent=strong;
 $("reportAvg").textContent=avg+"%";
}

// ------------------------------------------
// CANDIDATE DETAILS / EXPLAINABILITY
// ------------------------------------------

function showDetails(id) {
 const c=candidates.find(x=>x.id===id);
 if(!c)return;
 const a=c.analysis||analyzeCandidate(c).analysis;

 const details=`
 CANDIDATE INTELLIGENCE REPORT
 ${identity(c)}
 Overall compatibility: ${a.score}%
 Skills: ${a.skillScore}%
 Experience: ${a.experienceScore}%
 Projects: ${a.projectScore}%
 Education: ${a.educationScore}%

 MATCHED SKILLS:
 ${a.matched.join(", ")||"None"}

 SKILL GAPS:
 ${a.missing.join(", ")||"None"}

 TRANSFERABLE SKILL SIGNALS:
 ${a.hiddenSkills.join(", ")||"None"}

 VERIFICATION FLAGS:
 ${a.issues.join("\n")||"No automated flags"}

 INTERVIEW QUESTIONS:
 ${a.interviewQuestions.join("\n")}`;

 const box=document.createElement("div");
 box.style.cssText="position:fixed;inset:0;background:#000b;z-index:50;display:grid;place-items:center;padding:15px";
 box.innerHTML=`<div style="background:#111629;border:1px solid #6552a2;border-radius:14px;padding:25px;max-width:650px;width:100%;max-height:85vh;overflow:auto">
 <div style="display:flex;justify-content:space-between"><h2>${escapeHTML(identity(c))}</h2><button class="secondary" id="closeDetail">✕</button></div>
 <h3 style="color:#51d6a0">${a.score}% Overall Match</h3>
 <div class="detail-grid">
 ${[["Skills",a.skillScore],["Experience",a.experienceScore],["Projects",a.projectScore],["Education",a.educationScore]].map(([n,v])=>`<div class="metric"><small>${n}</small><b>${v}%</b></div>`).join("")}
 </div>
 <h3>Matched skills</h3><div class="badges">${a.matched.map(x=>`<span class="skill">${escapeHTML(x)}</span>`).join("")||"None"}</div>
 <h3 style="margin-top:20px">Skill gaps</h3><div class="badges">${a.missing.map(x=>`<span class="skill" style="color:#ffbd76">${escapeHTML(x)}</span>`).join("")||"No gaps detected"}</div>
 <h3 style="margin-top:20px">Transferable skill signals</h3><div class="badges">${a.hiddenSkills.map(x=>`<span class="skill">${escapeHTML(x)}</span>`).join("")||"None detected"}</div>
 <h3 style="margin-top:20px">Evidence and verification flags</h3>
 ${a.issues.map(x=>`<div class="evidence warning">${escapeHTML(x)}</div>`).join("")||'<div class="evidence good">No automated verification flags found.</div>'}
 <h3 style="margin-top:20px">Interview questions</h3>
 ${a.interviewQuestions.map((q,i)=>`<div class="evidence">${i+1}. ${escapeHTML(q)}</div>`).join("")}
 <button class="primary" id="downloadOne">Download candidate report</button>
 </div>`;
 document.body.appendChild(box);
 box.querySelector("#closeDetail").onclick=()=>box.remove();
 box.querySelector("#downloadOne").onclick=()=>downloadText(identity(c)+" report.txt",details);
}

// ------------------------------------------
// ANONYMOUS SCREENING
// ------------------------------------------

$("candidateSearch").addEventListener("input",renderCandidates);
$("sortCandidates").addEventListener("change",renderCandidates);

// ------------------------------------------
// CANDIDATE COMPARISON
// ------------------------------------------

function updateCompare() {
 $("compareSelect").innerHTML=candidates.map(c=>
 `<option value="${c.id}">${escapeHTML(identity(c))} (${c.analysis.score}%)</option>`
 ).join("");
}

$("compareBtn").addEventListener("click",()=>{
 const ids=[...$("compareSelect").selectedOptions].map(o=>Number(o.value));
 const list=candidates.filter(c=>ids.includes(c.id));
 if(list.length<2) {
  notify("Select at least two candidates");
  return;
 }

 const metrics=[
 ["Overall Match","score"],
 ["Technical Skills","skillScore"],
 ["Experience","experienceScore"],
 ["Projects","projectScore"],
 ["Education","educationScore"]
 ];

 $("compareResults").innerHTML=`
 <table class="compare-table">
 <tr><th>Metric</th>${list.map(c=>`<th>${escapeHTML(identity(c))}</th>`).join("")}</tr>
 ${metrics.map(([name,key])=>`<tr><td>${name}</td>${list.map(c=>`<td>${c.analysis[key]}%</td>`).join("")}</tr>`).join("")}
 </table>
 <h3 style="margin-top:25px">Skill comparison</h3>
 ${list.map(c=>`<div class="evidence"><b>${escapeHTML(identity(c))}:</b> ${c.analysis.matched.join(", ")||"No matching skills"}</div>`).join("")}`;
});

// ------------------------------------------
// IMPROVEMENT PORTAL
// ------------------------------------------

function updateImprove() {
 $("improveSelect").innerHTML=candidates.map(c=>
 `<option value="${c.id}">${escapeHTML(identity(c))}</option>`
 ).join("");
 renderImprove();
}

function renderImprove() {
 const c=candidates.find(x=>x.id===Number($("improveSelect").value));
 if(!c)return;
 const a=c.analysis;
 const suggestions={
  Python:"Practice Python functions, data structures and mini projects.",
  SQL:"Learn joins, subqueries, aggregations and window functions.",
  "Machine Learning":"Build classification and regression models.",
  Statistics:"Practice probability, hypothesis testing and distributions.",
  Pandas:"Work on data cleaning and transformation projects.",
  "Data Visualization":"Create dashboards using Power BI or Tableau.",
  NumPy:"Practice arrays, vectorization and numerical operations.",
  Java:"Practice OOP, collections and problem-solving.",
  "Deep Learning":"Build a small neural network and evaluate it.",
  PowerBI:"Create a dashboard from a real dataset."
 };

 $("improveResults").innerHTML=`
 <h3 style="margin-top:20px">${escapeHTML(identity(c))} – Development Report</h3>
 <div class="detail-grid">
 <div class="metric"><small>Current match</small><b>${a.score}%</b></div>
 <div class="metric"><small>Skill gaps</small><b>${a.missing.length}</b></div>
 <div class="metric"><small>Matched skills</small><b>${a.matched.length}</b></div>
 <div class="metric"><small>Projects</small><b>${c.projects.length}</b></div>
 </div>
 <h3>Recommended improvements</h3>
 ${a.missing.map(s=>`<div class="gap-item"><span>${escapeHTML(s)}</span><span class="warning">Needs improvement</span></div><div class="evidence">${escapeHTML(suggestions[s]||"Complete a practical exercise and build a project demonstrating this skill.")}</div>`).join("")||'<div class="evidence good">No identified skill gaps for this job description.</div>'}
 <h3 style="margin-top:20px">Recommended next steps</h3>
 <div class="evidence">1. Complete practical assignments for missing skills.</div>
 <div class="evidence">2. Build and document a job-relevant project.</div>
 <div class="evidence">3. Add measurable project outcomes to the resume.</div>`;
}

$("improveSelect").addEventListener("change",renderImprove);

// ------------------------------------------
// RECRUITER NATURAL LANGUAGE ASSISTANT
// ------------------------------------------

function askRecruiter(question) {
 const q=question.toLowerCase();
 let results=[];
 let response="";

 if(q.includes("best")||q.includes("top")) {
  results=[...candidates].sort((a,b)=>b.analysis.score-a.analysis.score).slice(0,3);
  response="Here are the highest-scoring candidates based on the current job description.";
 } else if(q.includes("python")||q.includes("sql")||q.includes("java")) {
  const skill=q.includes("python")?"Python":q.includes("sql")?"SQL":"Java";
  results=candidates.filter(c=>c.skills.includes(skill));
  response=`Found ${results.length} candidates with ${skill} listed in their resumes.`;
 } else if(q.includes("project")) {
  results=candidates.filter(c=>c.projects.length>=1);
  response="These candidates have project evidence in their profiles.";
 } else if(q.includes("gap")||q.includes("missing")) {
  results=candidates.filter(c=>c.analysis.missing.length>0);
  response="These candidates have identified skill gaps.";
 } else if(q.includes("experience")) {
  results=[...candidates].sort((a,b)=>b.experience-a.experience);
  response="Candidates ranked by reported experience.";
 } else if(q.includes("strong")) {
  results=candidates.filter(c=>c.analysis.score>=75);
  response="These candidates currently meet the strong-match threshold.";
 } else if(q.includes("average")||q.includes("score")) {
  const avg=Math.round(candidates.reduce((s,c)=>s+c.analysis.score,0)/candidates.length);
  response=`The average candidate match score is ${avg}%.`;
 } else if(q.includes("interview")) {
  const c=[...candidates].sort((a,b)=>b.analysis.score-a.analysis.score)[0];
  response=`Suggested interview questions for ${identity(c)}:\n${c.analysis.interviewQuestions.join("\n")}`;
  results=[c];
 } else {
  response="Try asking about the best candidate, Python or SQL skills, project experience, skill gaps, interview questions or average scores.";
 }

 return {response,results};
}

function sendMessage(q) {
 if(!q.trim())return;
 const chat=$("chatMessages");
 chat.innerHTML+=`<div class="message user">${escapeHTML(q)}</div>`;
 const answer=askRecruiter(q);
 chat.innerHTML+=`<div class="message bot">${escapeHTML(answer.response).replace(/\n/g,"<br>")}
 ${answer.results.length?answer.results.map(c=>`<div style="margin-top:10px;padding:9px;background:#12172c;border-radius:7px"><b>${escapeHTML(identity(c))}</b> — ${c.analysis.score}% match <button class="secondary" onclick="showDetails(${c.id})">View</button></div>`).join(""):""}
 </div>`;
 chat.scrollTop=chat.scrollHeight;
 $("chatInput").value="";
}

$("sendChat").addEventListener("click",()=>sendMessage($("chatInput").value));
$("chatInput").addEventListener("keydown",e=>{
 if(e.key==="Enter")sendMessage($("chatInput").value);
});
document.querySelectorAll(".quick-queries button").forEach(b=>{
 b.addEventListener("click",()=>sendMessage(b.dataset.query));
});

// ------------------------------------------
// EXPORTS
// ------------------------------------------

function downloadText(filename,text) {
 const blob=new Blob([text],{type:"text/plain"});
 const url=URL.createObjectURL(blob);
 const a=document.createElement("a");
 a.href=url;a.download=filename;a.click();
 URL.revokeObjectURL(url);
}

$("csvBtn").addEventListener("click",()=>{
 const rows=[
 ["Name","Match","Skills","Experience","Projects","Education","Missing Skills","Flags"],
 ...candidates.map(c=>[
  identity(c),c.analysis.score,
  c.analysis.skillScore,c.experience,
  c.analysis.projectScore,c.education,
  c.analysis.missing.join("; "),
  c.analysis.issues.join("; ")
 ])
 ];
 const csv=rows.map(row=>row.map(v=>'"'+String(v??"").replace(/"/g,'""')+'"').join(",")).join("\n");
 const blob=new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8"});
 const url=URL.createObjectURL(blob);
 const a=document.createElement("a");
 a.href=url;a.download="TalentLens_Candidate_Ranking.csv";a.click();
 URL.revokeObjectURL(url);
 notify("CSV report exported");
});

$("reportBtn").addEventListener("click",()=>{
 const report=candidates.map(c=>{
  const a=c.analysis;
  return `
================================
${identity(c)}
================================
Overall Match: ${a.score}%
Skills: ${a.skillScore}%
Experience: ${a.experienceScore}%
Projects: ${a.projectScore}%
Education: ${a.educationScore}%

Matched Skills: ${a.matched.join(", ")}
Skill Gaps: ${a.missing.join(", ")}
Transferable Signals: ${a.hiddenSkills.join(", ")}
Verification Flags: ${a.issues.join(", ")}

Interview Questions:
${a.interviewQuestions.join("\n")}
 `;
 }).join("\n");
 downloadText("TalentLens_Recruitment_Report.txt",report);
 notify("Recruitment report downloaded");
});

// ------------------------------------------
// INITIALIZATION
// ------------------------------------------

candidates.forEach(analyzeCandidate);
analyzed=true;
renderAll();
renderResults();
updateSuggested();
